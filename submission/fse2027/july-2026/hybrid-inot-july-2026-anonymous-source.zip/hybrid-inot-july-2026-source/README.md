# Anonymous Hybrid-INoT LaTeX source

Full manuscript in the ACM single-column anonymous review format. No scientific prose, results, formulas or original figures have been shortened.

With Python, pdfLaTeX, BibTeX and standard ACM dependencies installed, run `python build.py`. The resulting PDF is `paper/main.pdf`. The vendored acmart class is version2.20; its original licensed source is included under template-license/.

The anonymous evidence package is supplied separately as `hybrid-inot-july-2026-anonymous.zip`. This project contains no author metadata or historical author repository identifiers.
